// 동해사이 체크아웃. 봄내헬퍼 GTS 체크아웃 구조를 이식.
// 좌 요약 / 우 스티키 결제. 패스 3종 단일 선택, 결제 수단 그리드 8종, 환불 동의.
// Pay 활성 조건 넷: 패스 선택, 환불 동의, 결제 수단 선택, (필요 시) 필수 입력.
// 실제 결제 없음. i18n 과 통화 환산 제거, 원화 단일, 한국어 하드코딩.
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Loader2 } from 'lucide-react';
import PayMethodGrid from '../components/pay/PayMethodGrid';
import CardForm from '../components/pay/CardForm';
import { PAY_METHODS } from '../components/pay/payMethods';

// 동해사이 패스 3종. 값은 패스가격설계 자료 기준. 필요 시 데이터 파일로 분리한다.
const PASSES = [
  { id: 'day1', name: '1일권', price: 5000, included: '5개 권역 스탬프와 제휴 혜택 포함' },
  { id: 'day2', name: '2일권', price: 8000, included: '이틀 동안 모든 권역과 야간 콘텐츠 포함', featured: true },
  { id: 'day3', name: '3일권', price: 10000, included: '사흘 완주형. 별빛 프로그램까지 포함' },
];

const won = (n) => `${Number(n).toLocaleString('ko-KR')}원`;

export default function CheckoutPage() {
  const navigate = useNavigate();
  const [passType, setPassType] = useState(null);
  const [payMethod, setPayMethod] = useState(null);
  const [consent, setConsent] = useState(false);
  const [attempted, setAttempted] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const pass = PASSES.find((p) => p.id === passType) ?? null;
  const method = PAY_METHODS.find((m) => m.id === payMethod) ?? null;
  const total = pass ? pass.price : 0;

  const blocked = !passType || !consent || !method;
  const missing = [
    !passType && '이용권',
    !method && '결제 수단',
    !consent && '환불 동의',
  ].filter(Boolean);

  const onBlockedAttempt = () => setAttempted(true);

  const submit = async () => {
    setSubmitting(true);
    // 실제 결제 없음. 완료 화면으로 이동한다.
    setTimeout(() => navigate('/checkout/complete', { replace: true }), 400);
  };

  return (
    <div className="mx-auto w-full px-5 md:px-8 lg:px-12 xl:px-16 3xl:px-24 max-w-[1400px] 2xl:max-w-[1600px]">
      <div className="flex flex-col gap-8 pb-16 pt-12 lg:pt-16">
        <h1 className="font-pretendard text-[24px] md:text-[28px] lg:text-[32px] font-bold text-text-pri tracking-[-0.02em]">
          결제
        </h1>

        <div className="flex flex-col gap-6 lg:grid lg:grid-cols-[1fr_380px] lg:items-start lg:gap-6">
          {/* 좌 요약 */}
          <div className="flex flex-col gap-6">
            {/* 이용권 선택 */}
            <section className="flex flex-col gap-4 rounded-2xl bg-white p-6 shadow-card">
              <h2 className="font-pretendard text-[19px] font-semibold text-text-pri">이용권 선택</h2>
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
                {PASSES.map((p) => {
                  const selected = passType === p.id;
                  return (
                    <button
                      key={p.id}
                      type="button"
                      aria-pressed={selected}
                      onClick={() => setPassType(p.id)}
                      className={`flex flex-col gap-2 rounded-xl p-4 text-left transition-shadow duration-150 ${
                        selected ? 'bg-primary-soft ring-2 ring-inset ring-primary' : 'bg-bg-card'
                      }`}
                    >
                      <span className="font-pretendard text-[14px] font-semibold text-text-strong">{p.name}</span>
                      <span className="font-pretendard text-[19px] font-bold text-primary">{won(p.price)}</span>
                      <span className="font-pretendard text-[13px] font-medium text-text-sec leading-relaxed">{p.included}</span>
                    </button>
                  );
                })}
              </div>
            </section>

            {/* 결제 수단 */}
            <section className="flex flex-col gap-4 rounded-2xl bg-white p-6 shadow-card">
              <h2 className="font-pretendard text-[19px] font-semibold text-text-pri">결제 수단</h2>
              <PayMethodGrid value={payMethod} onChange={setPayMethod} />
              {attempted && !method && (
                <p aria-live="polite" className="font-pretendard text-[14px] font-medium text-spice">
                  결제 수단을 선택하세요.
                </p>
              )}
              {method && !method.wallet && <CardForm />}
            </section>
          </div>

          {/* 우 스티키 결제 */}
          <aside className="flex flex-col gap-6 rounded-2xl bg-white p-6 shadow-md lg:sticky lg:top-24">
            <h2 className="font-pretendard text-[19px] font-semibold text-text-pri">금액 내역</h2>

            {pass ? (
              <div className="flex flex-col gap-3">
                <div className="flex items-baseline justify-between gap-4">
                  <span className="font-pretendard text-[14px] font-medium text-text-sec">{pass.name}</span>
                  <span className="font-pretendard text-[15px] font-semibold text-text-strong">{won(pass.price)}</span>
                </div>
                <div aria-hidden="true" className="h-px w-full bg-border-sub" />
                <div className="flex items-baseline justify-between gap-4">
                  <span className="font-pretendard text-[14px] font-semibold text-text-strong">최종 금액</span>
                  <span className="font-pretendard text-[19px] font-bold text-primary">{won(total)}</span>
                </div>
              </div>
            ) : (
              <p className="font-pretendard text-[14px] font-medium text-text-sec">
                이용권을 선택하면 금액이 표시됩니다.
              </p>
            )}

            <p className="rounded-md bg-bg-card px-4 py-3 font-pretendard text-[13px] font-semibold text-text-sec">
              여기 표시된 금액이 전부입니다. 추가 비용은 없습니다.
            </p>

            {/* 취소 환불 */}
            <div className="flex flex-col gap-3 rounded-md bg-bg-card px-4 py-3">
              <h3 className="font-pretendard text-[14px] font-semibold text-text-strong">취소 및 환불</h3>
              <p className="font-pretendard text-[13px] font-medium text-text-sec leading-relaxed">
                시작 48시간 전까지 취소하면 보증금을 전액 환불합니다. 시작 48시간 이내에는 보증금을 환불하지 않습니다.
              </p>
              <label className="flex min-h-11 cursor-pointer items-center gap-3">
                <input
                  type="checkbox"
                  checked={consent}
                  onChange={(e) => setConsent(e.target.checked)}
                  className="h-5 w-5 shrink-0 accent-primary"
                />
                <span className="font-pretendard text-[14px] font-medium text-text-pri">
                  위 취소 및 환불 규정에 동의합니다.
                </span>
              </label>
            </div>

            {/* 결제 버튼 */}
            <div className="grid gap-2">
              <div className="grid" onClick={blocked && !submitting ? onBlockedAttempt : undefined}>
                <button
                  disabled={submitting || blocked}
                  onClick={submit}
                  className={`inline-flex h-12 items-center justify-center gap-2 rounded-full font-pretendard font-semibold text-white transition-shadow duration-150 ${
                    submitting || blocked ? 'bg-primary pointer-events-none opacity-40' : 'bg-primary hover:shadow-md'
                  }`}
                >
                  결제하기
                  {submitting && <Loader2 size={16} aria-hidden="true" className="animate-spin motion-reduce:animate-none" />}
                </button>
              </div>
              {blocked && !submitting && (
                <p aria-live="polite" className="font-pretendard text-[13px] font-medium text-text-sec">
                  아직 필요한 것: {missing.join(', ')}
                </p>
              )}
            </div>

            {/* 수정하기 */}
            <div className="grid">
              <button
                onClick={() => navigate(-1)}
                className="inline-flex h-12 items-center justify-center rounded-full bg-transparent font-pretendard font-semibold text-primary ring-[1.5px] ring-inset ring-primary transition-colors duration-150 hover:bg-primary-soft"
              >
                이전으로
              </button>
            </div>
          </aside>
        </div>
      </div>
    </div>
  );
}
