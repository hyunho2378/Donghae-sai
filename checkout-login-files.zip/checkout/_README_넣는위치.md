# 체크아웃과 로그인 완성 파일 넣는 위치

봄내헬퍼 GTS 체크아웃 구조를 동해사이용으로 이식한 완성 파일이다. 클로드 코드가 새로 짜지 않는다. 이 파일들을 아래 위치에 넣고 라우트만 연결하면 된다.

봄내헬퍼의 i18n 번역과 통화 환산과 GTS 여행 빌더 컨텍스트는 전부 걷어냈다. 원화 단일, 한국어 하드코딩, 동해사이 패스 3종에 맞췄다. 봄내헬퍼 토큰을 동해사이 표준 클래스로 치환했다. 다만 동해사이 tailwind 에 shadow-card 와 spice 토큰이 있어야 한다. 이건 P1 브랜드 시스템에서 만든다. P1 을 먼저 돌린 뒤 이 파일들을 넣는다.

## 파일 넣는 위치

- CheckoutPage.jsx → client/src/pages/CheckoutPage.jsx 로 덮어쓴다
- CheckoutCompletePage.jsx → client/src/pages/CheckoutCompletePage.jsx 로 덮어쓴다
- AuthPage.jsx → client/src/pages/AuthPage.jsx 로 덮어쓴다
- payMethods.js → client/src/components/pay/payMethods.js
- pay/PayMethodGrid.jsx → client/src/components/pay/PayMethodGrid.jsx
- pay/CardForm.jsx → client/src/components/pay/CardForm.jsx

pay 폴더가 없으면 client/src/components/pay 를 새로 만든다.

## 클로드 코드가 연결할 것

1. App.jsx 라우팅에 아래를 확인하고 없으면 잇는다
   - /checkout → CheckoutPage
   - /checkout/complete → CheckoutCompletePage
   - /login 또는 /auth → AuthPage
2. AuthPage 는 useAuthStore 의 setUser 를 쓴다. useAuthStore 에 setUser 와 user 가 있는지 확인하고 없으면 추가한다. 로그인 상태는 클라이언트 상태로만 두고 DB 나 서버에 남기지 않는다
3. 헤더 우측 로그인 버튼이 user 상태에 따라 로그인과 로그아웃으로 바뀌게 한다
4. 패스 값 5000 8000 10000 이 실제 동해사이 패스 데이터와 맞는지 확인한다. 다르면 CheckoutPage 상단 PASSES 배열의 price 만 맞춘다
5. 체크아웃으로 들어오는 진입 동선을 확인한다. 패스 페이지나 코스 상세에서 결제하기 버튼이 /checkout 으로 오게 한다

## 결제 로고 (현호가 넣을 것)

client/public/images/pay 에 아래 8개 svg 를 넣으면 자동으로 뜬다.
applepay.svg alipay.svg visa.svg mastercard.svg paypal.svg amex.svg jcb.svg unionpay.svg
넣기 전까지는 브랜드명 텍스트로 표시된다.
