// 동해사이 로그인. UI 만. 서버 연동과 DB 저장 없음. 아무 값이나 넣으면 통과한다.
// 구글 로그인 없음. 로그인 상태는 클라이언트 상태로만 표시한다.
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuthStore } from '../store/useAuthStore';

export default function AuthPage() {
  const navigate = useNavigate();
  const setUser = useAuthStore((s) => s.setUser);
  const [id, setId] = useState('');
  const [pw, setPw] = useState('');

  const submit = (e) => {
    e.preventDefault();
    // 검증 없음. 아무 값이나 통과. 상태만 세팅하고 DB 에 남기지 않는다.
    const name = id.trim() || '여행자';
    setUser({ name, id: name });
    navigate('/', { replace: true });
  };

  return (
    <div className="mx-auto flex min-h-[70vh] w-full max-w-[420px] flex-col justify-center px-5 py-16">
      <h1 className="font-pretendard text-[24px] font-bold text-text-pri tracking-[-0.02em]">로그인</h1>
      <p className="mt-2 font-pretendard text-[15px] font-normal text-text-meta">
        동해사이에 오신 것을 환영합니다.
      </p>

      <form onSubmit={submit} className="mt-8 flex flex-col gap-4">
        <label className="flex flex-col gap-2">
          <span className="font-pretendard text-[14px] font-semibold text-text-strong">아이디</span>
          <input
            type="text"
            value={id}
            onChange={(e) => setId(e.target.value)}
            placeholder="아이디를 입력하세요"
            className="h-12 rounded-md bg-bg-card px-4 font-pretendard text-[15px] text-text-pri focus:ring-2 focus:ring-inset focus:ring-primary"
          />
        </label>
        <label className="flex flex-col gap-2">
          <span className="font-pretendard text-[14px] font-semibold text-text-strong">비밀번호</span>
          <input
            type="password"
            value={pw}
            onChange={(e) => setPw(e.target.value)}
            placeholder="비밀번호를 입력하세요"
            className="h-12 rounded-md bg-bg-card px-4 font-pretendard text-[15px] text-text-pri focus:ring-2 focus:ring-inset focus:ring-primary"
          />
        </label>
        <button
          type="submit"
          className="mt-2 inline-flex h-12 items-center justify-center rounded-full bg-primary font-pretendard font-semibold text-white transition-shadow duration-150 hover:shadow-md"
        >
          로그인
        </button>
      </form>
    </div>
  );
}
