// 결제 수단 8종 정의. 로고 파일은 client/public/images/pay 에 아래 파일명으로 넣는다.
// applepay alipay visa mastercard paypal amex jcb unionpay .svg
// 파일이 없으면 브랜드명 텍스트로 폴백한다. 브랜드명은 고유명사라 번역하지 않는다.
export const PAY_METHODS = [
  { id: 'applepay', label: 'Apple Pay', file: '/images/pay/applepay.svg', wallet: true },
  { id: 'alipay', label: 'Alipay', file: '/images/pay/alipay.svg', wallet: true },
  { id: 'visa', label: 'Visa', file: '/images/pay/visa.svg', wallet: false },
  { id: 'mastercard', label: 'Mastercard', file: '/images/pay/mastercard.svg', wallet: false },
  { id: 'paypal', label: 'PayPal', file: '/images/pay/paypal.svg', wallet: false },
  { id: 'amex', label: 'American Express', file: '/images/pay/amex.svg', wallet: false },
  { id: 'jcb', label: 'JCB', file: '/images/pay/jcb.svg', wallet: false },
  { id: 'unionpay', label: 'UnionPay', file: '/images/pay/unionpay.svg', wallet: false },
];

// 로고별 시각 배율. SVG 내부 여백이 달라 같은 높이로 렌더해도 시각 크기가 다르다. 배율만 보정한다.
export const LOGO_SCALE = {
  alipay: 1.9,
  paypal: 1.4,
};

export const payMethodLabel = (id) => PAY_METHODS.find((m) => m.id === id)?.label ?? null;
