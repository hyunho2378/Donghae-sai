// 카드 입력 폼. 봄내헬퍼 구조를 동해사이용으로 이식. 검증 없음, 빈 제출 허용. 프로토타입.
// 자동 포맷만. 카드번호 4그룹, 만료 MM/YY, CVC 숫자 4자 상한. 마운트 시 펼침 연출.
import { useEffect, useState } from 'react';

const formatCardNumber = (v) =>
  v.replace(/\D/g, '').slice(0, 16).replace(/(\d{4})(?=\d)/g, '$1 ');

const formatExpiry = (v) => {
  const d = v.replace(/\D/g, '').slice(0, 4);
  return d.length > 2 ? `${d.slice(0, 2)}/${d.slice(2)}` : d;
};

function Field({ label, value, onChange, placeholder, inputMode, className = '' }) {
  return (
    <label className={`flex flex-col gap-2 ${className}`}>
      <span className="font-pretendard text-[14px] font-semibold text-text-strong">{label}</span>
      <input
        type="text"
        value={value}
        onChange={onChange}
        placeholder={placeholder}
        inputMode={inputMode}
        className="h-12 rounded-md bg-bg-card px-4 font-pretendard text-[15px] text-text-pri focus:ring-2 focus:ring-inset focus:ring-primary"
      />
    </label>
  );
}

export default function CardForm() {
  const [open, setOpen] = useState(false);
  const [card, setCard] = useState({ number: '', expiry: '', cvc: '', name: '' });

  useEffect(() => {
    const raf = requestAnimationFrame(() => setOpen(true));
    return () => cancelAnimationFrame(raf);
  }, []);

  const set = (key, format = (v) => v) => (e) =>
    setCard((c) => ({ ...c, [key]: format(e.target.value) }));

  return (
    <div className="grid"
         style={{ gridTemplateRows: open ? '1fr' : '0fr', transition: 'grid-template-rows 220ms ease-out' }}>
      <div className="overflow-hidden">
        <div className="flex flex-col gap-4 pt-2">
          <div className="grid gap-4 md:grid-cols-2">
            <Field label="카드 번호" value={card.number}
                   onChange={set('number', formatCardNumber)} inputMode="numeric"
                   placeholder="0000 0000 0000 0000" className="md:col-span-2" />
            <Field label="유효기간" value={card.expiry}
                   onChange={set('expiry', formatExpiry)} placeholder="MM/YY" inputMode="numeric" />
            <Field label="CVC" value={card.cvc}
                   onChange={set('cvc', (v) => v.replace(/\D/g, '').slice(0, 4))}
                   placeholder="000" inputMode="numeric" />
            <Field label="카드 소유자 이름" value={card.name}
                   onChange={set('name')} className="md:col-span-2" />
          </div>
          <p className="font-pretendard text-[13px] font-medium text-text-meta">
            프로토타입 화면입니다. 실제 결제가 이뤄지지 않습니다.
          </p>
        </div>
      </div>
    </div>
  );
}
