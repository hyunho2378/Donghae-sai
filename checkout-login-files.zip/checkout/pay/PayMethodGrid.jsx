// 결제 수단 그리드 8종. 봄내헬퍼 구조를 동해사이용으로 이식.
// 로고 파일이 없으면 svg → png → 텍스트 순으로 폴백해 깨진 이미지를 막는다.
// 선택 시 프라이머리 링. 단일 선택 라디오 그룹.
import { useState } from 'react';
import { PAY_METHODS, LOGO_SCALE } from './payMethods';

export default function PayMethodGrid({ value, onChange }) {
  const [stage, setStage] = useState({});
  const fail = (id) =>
    setStage((s) => ({ ...s, [id]: s[id] === 'png' ? 'text' : 'png' }));

  return (
    <div role="radiogroup" aria-label="결제 수단"
         className="grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-4">
      {PAY_METHODS.map((method) => {
        const selected = value === method.id;
        return (
          <button
            key={method.id}
            type="button"
            role="radio"
            aria-checked={selected}
            onClick={() => onChange(method.id)}
            className={`flex min-h-[96px] flex-col items-center justify-center gap-2 rounded-xl bg-white p-5 shadow-card transition-shadow duration-150 ${
              selected ? 'ring-2 ring-primary' : 'hover:shadow-md'
            }`}
          >
            {stage[method.id] === 'text' ? (
              <span className="font-pretendard text-[18px] font-semibold text-text-strong">{method.label}</span>
            ) : (
              <img
                src={stage[method.id] === 'png' ? method.file.replace(/\.svg$/, '.png') : method.file}
                alt={method.label}
                className="h-16 w-auto object-contain"
                style={LOGO_SCALE[method.id] ? { transform: `scale(${LOGO_SCALE[method.id]})` } : undefined}
                onError={() => fail(method.id)}
              />
            )}
          </button>
        );
      })}
    </div>
  );
}
