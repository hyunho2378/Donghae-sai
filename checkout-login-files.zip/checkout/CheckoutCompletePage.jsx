// 동해사이 결제 완료. 프로토타입. 실제 결제 없음.
import { Link } from 'react-router-dom';
import { Check } from 'lucide-react';

export default function CheckoutCompletePage() {
  return (
    <div className="mx-auto flex min-h-[70vh] w-full max-w-[560px] flex-col items-center justify-center px-5 py-16 text-center">
      <span className="flex h-16 w-16 items-center justify-center rounded-full bg-primary-soft">
        <Check size={32} className="text-primary" />
      </span>
      <h1 className="mt-6 font-pretendard text-[24px] font-bold text-text-pri tracking-[-0.02em]">
        결제가 완료됐습니다
      </h1>
      <p className="mt-3 font-pretendard text-[15px] font-normal text-text-sec leading-relaxed">
        동해사이 패스가 발급됐습니다. 마이 패스에서 스탬프를 모아 하룻밤을 완성하세요.
      </p>
      <p className="mt-2 font-pretendard text-[13px] font-medium text-text-meta">
        프로토타입 화면입니다. 실제 결제가 이뤄지지 않습니다.
      </p>
      <div className="mt-8 flex gap-3">
        <Link to="/pass" className="inline-flex h-12 items-center justify-center rounded-full bg-primary px-6 font-pretendard font-semibold text-white hover:shadow-md">
          마이 패스로
        </Link>
        <Link to="/" className="inline-flex h-12 items-center justify-center rounded-full bg-transparent px-6 font-pretendard font-semibold text-primary ring-[1.5px] ring-inset ring-primary hover:bg-primary-soft">
          홈으로
        </Link>
      </div>
    </div>
  );
}
